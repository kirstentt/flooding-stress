function [Dshoot,Droot] = OxygenDiffusion(Par,PhoStomata,O2shoot,O2root,O2soil,ROLB)

% Effective plant-environment diffusivity to oxygen in shoot and root
% Represented by the proportion of diffusivity compared to that during non-stress conditions
WaterDiffShoot = PhoStomata;
WaterDiffRoot = Par.DwaterO2 + (1 - Par.DwaterO2) * Par.Kroot^10 ...
    / (Par.Hwater^10 + Par.Kroot^10);

% The effective air-shoot and soil-root diffusion rates
Dshoot    = Par.DairShoot * WaterDiffShoot * (Par.O2air - O2shoot) * Par.Sp;
Droot     = Par.DsoilRoot * (1 - ROLB) * WaterDiffRoot * (O2soil - O2root) * Par.Sr;

end